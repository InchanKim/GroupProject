# Group 2 Research Question
##### Isabella Hundley, Admir Isnaeni, Inchan Kim, Peyton Thompson

Do intenships have an impact on the salary, location, and employer of LSU's college graduates?
* Is the probability of an employed alumnus being in a higher income bracket affected by having previous internships and the type of internship they had?  
  + Comparison of Paid vs. Unpaid
   - Overall for LSU graduates  
   - Breakdown by major  
      > https://www.kaggle.com/wsj/college-salaries/data  
      (Comparison: Dataset from Wall Street Journal of salary by major, college type, and region.)   
* Do employed graduates tend to go out of state (LA)?  
   + Are there trends regarding the following factors?
    - The graduate's Home State (Louisiana or out of state)
    - Internship Location
    - Major
* Do employed graduates tend to work for the employer that they interned with?  
   + Are there trends regarding the following factors?
    - The graduate's Home State (Louisiana or out of state)
    - Internship Location
    - Major
    
Conclusion: Analysis Report
    
